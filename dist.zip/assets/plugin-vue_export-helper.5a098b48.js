var a=(r,o)=>{for(const[e,t]of o)r[e]=t;return r};export{a as _};
